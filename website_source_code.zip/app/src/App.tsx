import { Navigation } from "@/components/layout/navigation";
import { Footer } from "@/components/layout/footer";
import { Hero } from "@/sections/Hero";
import { TrustSignals } from "@/sections/TrustSignals";
import { CourseCategories } from "@/sections/CourseCategories";
import { Features } from "@/sections/Features";
import { FeaturedCourse } from "@/sections/FeaturedCourse";
import { TrainingSchedule } from "@/sections/TrainingSchedule";
import { ConsultingCTA } from "@/sections/ConsultingCTA";

function App() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main>
        <Hero />
        <TrustSignals />
        <CourseCategories />
        <Features />
        <FeaturedCourse />
        <TrainingSchedule />
        <ConsultingCTA />
      </main>
      <Footer />
    </div>
  );
}

export default App;
