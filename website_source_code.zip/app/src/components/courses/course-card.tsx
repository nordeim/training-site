"use client";

import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, Clock, Users, ArrowRight, Zap, BookOpen } from "lucide-react";
import { fadeUpItem, cardHover } from "@/lib/animations";
import { cn } from "@/lib/utils";
import type { Course } from "@/types";

interface CourseCardProps {
  course: Course;
  variant?: "default" | "featured" | "compact";
  index?: number;
}

export function CourseCard({ course }: CourseCardProps) {
  const isUrgent = course.spotsRemaining && course.spotsRemaining <= 5;
  const accentColor = course.categoryColor || "var(--color-primary-600)";
  
  const levelColors = {
    "Beginner": "bg-emerald-500/80",
    "Intermediate": "bg-amber-500/80",
    "Advanced": "bg-primary-600/80",
  };
  
  return (
    <motion.article
      variants={fadeUpItem}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-50px" }}
      whileHover="hover"
      className="group relative bg-surface overflow-hidden transition-colors"
      style={{ borderTop: `3px solid ${accentColor}` }}
    >
      <motion.div 
        variants={cardHover} 
        className="h-full flex flex-col border border-border border-t-0"
      >
        {/* Badge */}
        {course.badge && (
          <div className="absolute top-4 right-4 z-10">
            <Badge 
              variant={course.badge.variant === 'urgent' ? 'destructive' : 
                      course.badge.variant === 'popular' ? 'default' : 
                      course.badge.variant === 'new' ? 'secondary' : 'outline'} 
              className="shadow-lg"
            >
              {course.badge.text}
            </Badge>
          </div>
        )}

        {/* Thumbnail */}
        <div className="relative aspect-video overflow-hidden block">
          <img
            src={course.thumbnail.src}
            alt={course.thumbnail.alt}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
        
          {/* Level Badge */}
          <div className="absolute bottom-4 left-4">
            <span className={cn(
              "px-3 py-1 text-xs font-medium text-white backdrop-blur-md",
              levelColors[course.level]
            )}>
              {course.level}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 p-6 flex flex-col">
          {/* Categories (Monospace labels - from iTrust pattern) */}
          <div className="flex flex-wrap gap-2 mb-3">
            {course.categories.slice(0, 2).map((cat) => (
              <span key={cat} className="label-mono text-text-tertiary">
                {cat}
              </span>
            ))}
          </div>

          <h3 className="text-xl font-semibold tracking-tight mb-2 line-clamp-2 group-hover:text-primary-600 transition-colors font-display">
            {course.title}
          </h3>
        
          <p className="text-text-secondary text-sm mb-4 line-clamp-2 flex-1">
            {course.subtitle}
          </p>

          {/* Meta Row */}
          <div className="flex items-center gap-4 text-sm text-text-tertiary mb-4">
            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" aria-hidden="true" />
              {course.duration}
            </span>
            <span className="flex items-center gap-1.5">
              <Users className="w-4 h-4" aria-hidden="true" />
              {course.enrolledCount.toLocaleString()}
            </span>
            <span className="flex items-center gap-1.5">
              <BookOpen className="w-4 h-4" aria-hidden="true" />
              {course.modules.length} modules
            </span>
          </div>

          {/* Rating */}
          <div className="flex items-center gap-2 mb-4">
            <div className="flex items-center" aria-label={`Rating: ${course.rating} out of 5 stars`}>
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={cn(
                    "w-4 h-4",
                    i < Math.floor(course.rating)
                      ? "fill-amber-400 text-amber-400"
                      : "text-border"
                  )}
                  aria-hidden="true"
                />
              ))}
            </div>
            <span className="text-sm font-medium text-text-primary">
              {course.rating}
            </span>
            <span className="text-sm text-text-tertiary">
              ({course.reviewCount.toLocaleString()})
            </span>
          </div>

          {/* Price & CTA */}
          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div className="flex flex-col">
              <span className="text-2xl font-bold text-primary-600">
                ${course.price.amount.toLocaleString()}
              </span>
              {course.price.original && (
                <span className="text-sm text-text-tertiary line-through">
                  ${course.price.original.toLocaleString()}
                </span>
              )}
            </div>
            <Button variant="default" size="sm" className="gap-2">
              Enroll
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
            </Button>
          </div>

          {/* Urgency Indicator (from iTrust pattern) */}
          {isUrgent && (
            <div className="mt-3 flex items-center gap-2 text-sm text-amber-600 font-medium animate-pulse">
              <Zap className="w-4 h-4" aria-hidden="true" />
              Only {course.spotsRemaining} spots remaining
            </div>
          )}
        </div>
      </motion.div>
    </motion.article>
  );
}
