"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  text: string;
  variant: "enrolling" | "available" | "filling-fast" | "waitlist" | "closed";
  withPulse?: boolean;
  className?: string;
}

const variantStyles = {
  enrolling: {
    bg: "bg-primary-100",
    border: "border-primary-500/25",
    text: "text-primary-700",
    indicator: "bg-primary-500",
  },
  available: {
    bg: "bg-emerald-50",
    border: "border-emerald-500/25",
    text: "text-emerald-700",
    indicator: "bg-emerald-500",
  },
  "filling-fast": {
    bg: "bg-amber-50",
    border: "border-amber-500/25",
    text: "text-amber-700",
    indicator: "bg-amber-500",
  },
  waitlist: {
    bg: "bg-slate-50",
    border: "border-slate-500/25",
    text: "text-slate-700",
    indicator: "bg-slate-400",
  },
  closed: {
    bg: "bg-gray-50",
    border: "border-gray-500/25",
    text: "text-gray-700",
    indicator: "bg-gray-400",
  },
};

export function StatusBadge({ text, variant, withPulse = false, className }: StatusBadgeProps) {
  const styles = variantStyles[variant];
  
  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 px-4 py-2 border",
        styles.bg,
        styles.border,
        className
      )}
    >
      {withPulse && (
        <motion.span
          className={cn("w-2 h-2", styles.indicator)}
          animate={{ opacity: [1, 0.4, 1] }}
          transition={{ duration: 2, ease: "easeInOut", repeat: Infinity }}
        />
      )}
      <span className={cn("label-mono", styles.text)}>{text}</span>
    </div>
  );
}
