// Animation easings and durations from PRD
export const easings = {
  smooth: [0.25, 0.46, 0.45, 0.94] as const,    // Smooth deceleration
  snappy: [0.4, 0, 0.2, 1] as const,             // Micro-interactions
  bounce: [0.68, -0.55, 0.265, 1.55] as const,   // Celebratory
};

export const durations = {
  instant: 0.1,
  fast: 0.2,      // Buttons, nav items (from iTrust: 0.2s)
  normal: 0.3,    // Cards, sections (from iTrust: 0.25-0.3s)
  slow: 0.5,
  dramatic: 0.8,
} as const;

// Page load stagger container
export const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.1,
    },
  },
};

// Fade up item animation
export const fadeUpItem = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: durations.slow,
      ease: easings.smooth,
    },
  },
};

// Fade in animation
export const fadeIn = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      duration: durations.normal,
      ease: easings.smooth,
    },
  },
};

// Scale up animation
export const scaleUp = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: durations.normal,
      ease: easings.smooth,
    },
  },
};

// Slide in from right
export const slideInRight = {
  hidden: { opacity: 0, x: 50 },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      duration: durations.slow,
      ease: easings.smooth,
    },
  },
};

// Slide in from left
export const slideInLeft = {
  hidden: { opacity: 0, x: -50 },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      duration: durations.slow,
      ease: easings.smooth,
    },
  },
};

// Card hover (from iTrust: transition 0.25s)
export const cardHover = {
  rest: { 
    y: 0, 
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    transition: { duration: durations.normal, ease: easings.smooth }
  },
  hover: { 
    y: -4, 
    boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
    transition: { duration: durations.normal, ease: easings.smooth }
  },
};

// Button press
export const buttonTap = {
  scale: 0.98,
  transition: { duration: durations.instant },
};

// Pulse animation (from iTrust: 2s ease infinite)
export const pulseIndicator = {
  animate: {
    opacity: [1, 0.4, 1],
    transition: {
      duration: 2,
      ease: 'easeInOut',
      repeat: Infinity,
    },
  },
};

// Navigation item hover
export const navItemHover = {
  rest: { scale: 1 },
  hover: { 
    scale: 1.02,
    transition: { duration: durations.fast, ease: easings.snappy }
  },
};

// Stagger children with custom delay
export const createStaggerContainer = (staggerChildren: number = 0.1, delayChildren: number = 0) => ({
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren,
      delayChildren,
    },
  },
});

// Viewport animation settings
export const viewportOnce = {
  once: true,
  margin: "-50px",
};

// Hero specific animations
export const heroStagger = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.2,
    },
  },
};

export const heroItem = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: durations.dramatic,
      ease: easings.smooth,
    },
  },
};

// Section reveal animation
export const sectionReveal = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: durations.slow,
      ease: easings.smooth,
    },
  },
};

// Grid item animation
export const gridItem = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: durations.normal,
      ease: easings.smooth,
    },
  },
};
