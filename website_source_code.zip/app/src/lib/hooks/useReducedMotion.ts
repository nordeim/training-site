import { useState, useEffect } from 'react';

/**
 * Hook to detect user's preference for reduced motion
 * Used for accessibility compliance (WCAG AAA)
 */
export function useReducedMotion(): boolean {
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  useEffect(() => {
    // Check if window is available (SSR safety)
    if (typeof window === 'undefined') return;

    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);

    const handler = (event: MediaQueryListEvent) => {
      setPrefersReducedMotion(event.matches);
    };

    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  return prefersReducedMotion;
}

/**
 * Hook to get animation props based on reduced motion preference
 * Returns animation props or empty object if reduced motion is preferred
 */
export function useAnimationProps() {
  const prefersReducedMotion = useReducedMotion();

  return {
    initial: prefersReducedMotion ? undefined : 'hidden',
    animate: prefersReducedMotion ? undefined : 'visible',
    whileInView: prefersReducedMotion ? undefined : 'visible',
    viewport: prefersReducedMotion ? undefined : { once: true, margin: '-50px' },
  };
}
