"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { staggerContainer, fadeUpItem } from "@/lib/animations";
import { useReducedMotion } from "@/lib/hooks/useReducedMotion";
import { ArrowRight, Building2, Users, GraduationCap, MessageSquare } from "lucide-react";

export function ConsultingCTA() {
  const prefersReducedMotion = useReducedMotion();
  
  const containerVariants = prefersReducedMotion ? {} : staggerContainer;
  const itemVariants = prefersReducedMotion ? {} : fadeUpItem;

  const benefits = [
    {
      icon: Building2,
      title: "Custom Curriculum",
      description: "Tailored programs aligned with your tech stack and business goals.",
    },
    {
      icon: Users,
      title: "Team Training",
      description: "Upskill your entire engineering team with private cohorts.",
    },
    {
      icon: GraduationCap,
      title: "Volume Discounts",
      description: "Competitive pricing for teams of 10 or more learners.",
    },
    {
      icon: MessageSquare,
      title: "Dedicated Support",
      description: "Personal account manager and priority support channel.",
    },
  ];

  return (
    <section id="enterprise" className="section-padding bg-primary-600 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 grid-pattern" />
      </div>
      
      {/* Decorative Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-400/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-primary-400/30 rounded-full blur-3xl" />

      <div className="relative max-w-container mx-auto px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
        >
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Column - Content */}
            <motion.div variants={itemVariants}>
              <span className="label-mono text-cyan-300 mb-4 block">
                ENTERPRISE SOLUTIONS
              </span>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 font-display">
                Train Your Team at Scale
              </h2>
              <p className="text-primary-100 text-lg mb-8 leading-relaxed">
                Empower your engineering organization with world-class AI and software training. 
                Our enterprise programs are trusted by Fortune 500 companies and high-growth startups alike.
              </p>

              <div className="flex flex-wrap gap-4">
                <Button 
                  size="lg" 
                  variant="secondary"
                  className="gap-2 bg-white text-primary-600 hover:bg-primary-50"
                >
                  Request a Demo
                  <ArrowRight className="w-4 h-4" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  className="gap-2 border-white/30 text-white hover:bg-white/10"
                >
                  Talk to Sales
                </Button>
              </div>
            </motion.div>

            {/* Right Column - Benefits */}
            <motion.div variants={itemVariants} className="grid sm:grid-cols-2 gap-6">
              {benefits.map((benefit) => {
                const IconComponent = benefit.icon;
                
                return (
                  <motion.div
                    key={benefit.title}
                    variants={itemVariants}
                    className="bg-white/10 backdrop-blur-sm border border-white/20 p-6"
                  >
                    <div className="w-10 h-10 bg-cyan-400/20 flex items-center justify-center mb-4">
                      <IconComponent className="w-5 h-5 text-cyan-300" />
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2 font-display">
                      {benefit.title}
                    </h3>
                    <p className="text-sm text-primary-100">
                      {benefit.description}
                    </p>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>

          {/* Stats Row */}
          <motion.div 
            variants={itemVariants}
            className="mt-16 pt-8 border-t border-white/20"
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              <div>
                <div className="text-3xl md:text-4xl font-bold text-white font-display">500+</div>
                <div className="text-sm text-primary-200 mt-1">Enterprise Clients</div>
              </div>
              <div>
                <div className="text-3xl md:text-4xl font-bold text-white font-display">50K+</div>
                <div className="text-sm text-primary-200 mt-1">Engineers Trained</div>
              </div>
              <div>
                <div className="text-3xl md:text-4xl font-bold text-white font-display">95%</div>
                <div className="text-sm text-primary-200 mt-1">Satisfaction Rate</div>
              </div>
              <div>
                <div className="text-3xl md:text-4xl font-bold text-white font-display">24/7</div>
                <div className="text-sm text-primary-200 mt-1">Support Available</div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
