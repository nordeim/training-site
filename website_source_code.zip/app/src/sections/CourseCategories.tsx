"use client";

import { motion } from "framer-motion";
import { staggerContainer, fadeUpItem } from "@/lib/animations";
import { useReducedMotion } from "@/lib/hooks/useReducedMotion";
import { courseCategories } from "@/data/mockData";
import { Brain, BarChart3, Cloud, Shield, GitBranch, Code2, ArrowRight } from "lucide-react";

const iconMap: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  Brain,
  BarChart3,
  Cloud,
  Shield,
  GitBranch,
  Code2,
};

export function CourseCategories() {
  const prefersReducedMotion = useReducedMotion();
  
  const containerVariants = prefersReducedMotion ? {} : staggerContainer;
  const itemVariants = prefersReducedMotion ? {} : fadeUpItem;

  return (
    <section id="courses" className="section-padding bg-background">
      <div className="max-w-container mx-auto px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
        >
          {/* Section Header */}
          <motion.div variants={itemVariants} className="text-center mb-12">
            <span className="label-mono text-primary-600 mb-4 block">
              LEARNING PATHS
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-text-primary mb-4 font-display">
              Choose Your Specialization
            </h2>
            <p className="text-text-secondary text-lg max-w-2xl mx-auto">
              Industry-aligned curricula designed by engineers from top tech companies. 
              Master the skills that employers demand.
            </p>
          </motion.div>

          {/* Categories Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {courseCategories.map((category) => {
              const IconComponent = iconMap[category.icon] || Brain;
              
              return (
                <motion.a
                  key={category.id}
                  href={`#${category.slug}`}
                  variants={itemVariants}
                  className="group relative bg-surface border border-border overflow-hidden transition-all duration-300 hover:shadow-card-hover card-hover"
                  style={{ borderTop: `3px solid ${category.color}` }}
                >
                  <div className="p-6">
                    {/* Icon */}
                    <div 
                      className="w-12 h-12 flex items-center justify-center mb-4 transition-transform duration-300 group-hover:scale-110"
                      style={{ backgroundColor: `${category.color}15` }}
                    >
                      <IconComponent 
                        className="w-6 h-6" 
                        style={{ color: category.color }}
                      />
                    </div>

                    {/* Content */}
                    <h3 className="text-xl font-semibold text-text-primary mb-2 font-display group-hover:text-primary-600 transition-colors">
                      {category.name}
                    </h3>
                    <p className="text-text-secondary text-sm mb-4 line-clamp-2">
                      {category.description}
                    </p>

                    {/* Footer */}
                    <div className="flex items-center justify-between pt-4 border-t border-border">
                      <span className="text-sm text-text-tertiary">
                        {category.courseCount} courses
                      </span>
                      <span className="flex items-center gap-1 text-sm font-medium text-primary-600 opacity-0 group-hover:opacity-100 transition-opacity">
                        Explore
                        <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                      </span>
                    </div>
                  </div>
                </motion.a>
              );
            })}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
