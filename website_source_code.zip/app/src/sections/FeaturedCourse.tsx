"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { staggerContainer, fadeUpItem, slideInLeft, slideInRight } from "@/lib/animations";
import { useReducedMotion } from "@/lib/hooks/useReducedMotion";
import { courses } from "@/data/mockData";
import { Check, ArrowRight, Star, Clock, Users, BookOpen, Zap } from "lucide-react";

export function FeaturedCourse() {
  const prefersReducedMotion = useReducedMotion();
  
  const containerVariants = prefersReducedMotion ? {} : staggerContainer;
  const itemVariants = prefersReducedMotion ? {} : fadeUpItem;
  
  // Get the featured course (AI Engineering Bootcamp)
  const featuredCourse = courses.find(c => c.slug === 'ai-engineering-bootcamp') || courses[0];

  const inclusions = [
    "Live instruction + recordings",
    "Hands-on lab environments",
    "Certification exam voucher",
    "1-year community access",
    "Career support & job referrals",
    "Lifetime content updates",
  ];

  return (
    <section className="section-padding bg-background">
      <div className="max-w-container mx-auto px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
        >
          {/* Section Header */}
          <motion.div variants={itemVariants} className="text-center mb-12">
            <span className="label-mono text-primary-600 mb-4 block">
              FEATURED PROGRAM
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-text-primary mb-4 font-display">
              Our Flagship Course
            </h2>
          </motion.div>

          {/* Featured Course Content */}
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
            {/* Left Column - Course Image & Info */}
            <motion.div 
              variants={prefersReducedMotion ? itemVariants : slideInLeft}
              className="relative"
            >
              <div className="relative aspect-video overflow-hidden border border-border">
                <img
                  src={featuredCourse.thumbnail.src}
                  alt={featuredCourse.thumbnail.alt}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                
                {/* Badge */}
                <div className="absolute top-4 left-4">
                  <Badge className="bg-primary-600 text-white">
                    {featuredCourse.badge?.text || "Featured"}
                  </Badge>
                </div>

                {/* Stats Overlay */}
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-white">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1 text-sm">
                      <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                      {featuredCourse.rating}
                    </span>
                    <span className="flex items-center gap-1 text-sm">
                      <Users className="w-4 h-4" />
                      {featuredCourse.enrolledCount.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="bg-surface border border-border p-4 text-center">
                  <Clock className="w-5 h-5 text-primary-600 mx-auto mb-2" />
                  <div className="text-sm font-medium text-text-primary">{featuredCourse.duration}</div>
                  <div className="text-xs text-text-tertiary">Duration</div>
                </div>
                <div className="bg-surface border border-border p-4 text-center">
                  <BookOpen className="w-5 h-5 text-primary-600 mx-auto mb-2" />
                  <div className="text-sm font-medium text-text-primary">{featuredCourse.modules.length}</div>
                  <div className="text-xs text-text-tertiary">Modules</div>
                </div>
                <div className="bg-surface border border-border p-4 text-center">
                  <Zap className="w-5 h-5 text-primary-600 mx-auto mb-2" />
                  <div className="text-sm font-medium text-text-primary">{featuredCourse.level}</div>
                  <div className="text-xs text-text-tertiary">Level</div>
                </div>
              </div>
            </motion.div>

            {/* Right Column - Details */}
            <motion.div 
              variants={prefersReducedMotion ? itemVariants : slideInRight}
              className="flex flex-col"
            >
              <h3 className="text-2xl md:text-3xl font-bold text-text-primary mb-4 font-display">
                {featuredCourse.title}
              </h3>
              
              <p className="text-text-secondary mb-6">
                {featuredCourse.description}
              </p>

              {/* Skills */}
              <div className="mb-6">
                <h4 className="text-sm font-medium text-text-primary mb-3 label-mono">
                  SKILLS YOU WILL MASTER
                </h4>
                <div className="flex flex-wrap gap-2">
                  {featuredCourse.skills.map((skill) => (
                    <span 
                      key={skill}
                      className="px-3 py-1 bg-surface-alt border border-border text-sm text-text-secondary"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* What's Included */}
              <div className="mb-8">
                <h4 className="text-sm font-medium text-text-primary mb-3 label-mono">
                  WHAT&apos;S INCLUDED
                </h4>
                <ul className="space-y-2">
                  {inclusions.map((item) => (
                    <li key={item} className="flex items-center gap-2 text-sm text-text-secondary">
                      <Check className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Price & CTA */}
              <div className="mt-auto pt-6 border-t border-border">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-3">
                      <span className="text-3xl font-bold text-primary-600 font-display">
                        ${featuredCourse.price.amount.toLocaleString()}
                      </span>
                      {featuredCourse.price.original && (
                        <span className="text-lg text-text-tertiary line-through">
                          ${featuredCourse.price.original.toLocaleString()}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-text-tertiary mt-1">
                      Next cohort starts {new Date(featuredCourse.nextCohort).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                    </p>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-4">
                  <Button size="lg" className="gap-2">
                    Enroll Now
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="lg">
                    View Syllabus
                  </Button>
                </div>

                {/* Urgency */}
                {featuredCourse.spotsRemaining && featuredCourse.spotsRemaining <= 5 && (
                  <p className="mt-4 text-sm text-amber-600 font-medium flex items-center gap-2 animate-pulse">
                    <Zap className="w-4 h-4" />
                    Only {featuredCourse.spotsRemaining} spots remaining in this cohort
                  </p>
                )}
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
