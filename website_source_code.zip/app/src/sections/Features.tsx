"use client";

import { motion } from "framer-motion";
import { staggerContainer, fadeUpItem } from "@/lib/animations";
import { useReducedMotion } from "@/lib/hooks/useReducedMotion";
import { features } from "@/data/mockData";
import { Video, Laptop, Briefcase, Award, Users, Infinity } from "lucide-react";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Video,
  Laptop,
  Briefcase,
  Award,
  Users,
  Infinity,
};

export function Features() {
  const prefersReducedMotion = useReducedMotion();
  
  const containerVariants = prefersReducedMotion ? {} : staggerContainer;
  const itemVariants = prefersReducedMotion ? {} : fadeUpItem;

  return (
    <section className="section-padding bg-surface-alt">
      <div className="max-w-container mx-auto px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
        >
          {/* Section Header */}
          <motion.div variants={itemVariants} className="text-center mb-12">
            <span className="label-mono text-primary-600 mb-4 block">
              WHY CHOOSE US
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-text-primary mb-4 font-display">
              Learn Without Limits
            </h2>
            <p className="text-text-secondary text-lg max-w-2xl mx-auto">
              Our programs are designed for working professionals who want to 
              advance their careers with cutting-edge skills.
            </p>
          </motion.div>

          {/* Features Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature) => {
              const IconComponent = iconMap[feature.icon] || Laptop;
              
              return (
                <motion.div
                  key={feature.id}
                  variants={itemVariants}
                  className="group bg-surface border border-border p-6 transition-all duration-300 hover:shadow-card-hover card-hover"
                >
                  {/* Icon */}
                  <div className="w-12 h-12 bg-primary-100 flex items-center justify-center mb-4 transition-transform duration-300 group-hover:scale-110">
                    <IconComponent className="w-6 h-6 text-primary-600" />
                  </div>

                  {/* Content */}
                  <h3 className="text-lg font-semibold text-text-primary mb-2 font-display">
                    {feature.title}
                  </h3>
                  <p className="text-text-secondary text-sm">
                    {feature.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
