"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { heroStagger, heroItem } from "@/lib/animations";
import { useReducedMotion } from "@/lib/hooks/useReducedMotion";
import { ArrowRight, Play, Sparkles, TrendingUp, Users } from "lucide-react";
import { platformStats } from "@/data/mockData";

export function Hero() {
  const prefersReducedMotion = useReducedMotion();

  const containerVariants = prefersReducedMotion ? {} : heroStagger;
  const itemVariants = prefersReducedMotion ? {} : heroItem;

  return (
    <section className="relative min-h-[92vh] flex items-center overflow-hidden border-b border-border bg-background">
      {/* Grid Background Pattern */}
      <div className="absolute inset-0 grid-pattern opacity-50" />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary-50/50 via-transparent to-cyan-50/30 dark:from-primary-900/20 dark:to-cyan-900/10" />
      
      {/* Animated Background Elements */}
      {!prefersReducedMotion && (
        <>
          <motion.div
            className="absolute top-20 right-20 w-72 h-72 bg-primary-400/10 rounded-full blur-3xl"
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.5, 0.3],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          <motion.div
            className="absolute bottom-20 left-20 w-96 h-96 bg-cyan-400/10 rounded-full blur-3xl"
            animate={{
              scale: [1.2, 1, 1.2],
              opacity: [0.2, 0.4, 0.2],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        </>
      )}

      <div className="relative w-full max-w-container mx-auto px-6 py-20 md:py-32">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Column - Content */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="flex flex-col"
          >
            {/* Status Badge */}
            <motion.div variants={itemVariants} className="mb-6">
              <StatusBadge 
                text="Now Enrolling: April Cohorts" 
                variant="enrolling" 
                withPulse 
              />
            </motion.div>

            {/* Main Headline */}
            <motion.h1 
              variants={itemVariants}
              className="font-mono text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tighter text-text-primary mb-6"
            >
              <span className="text-primary-600 animate-pulse">_</span>
              MASTER AI
              <br />
              ENGINEERING
            </motion.h1>

            {/* Subheadline */}
            <motion.p 
              variants={itemVariants}
              className="text-lg md:text-xl text-text-secondary max-w-xl mb-8 leading-relaxed"
            >
              Build production-grade AI systems in 12 weeks. Live instruction, 
              hands-on labs, and career support from industry experts at Google, 
              Netflix, and OpenAI.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div 
              variants={itemVariants}
              className="flex flex-wrap gap-4 mb-10"
            >
              <Button 
                size="lg" 
                className="gap-2 text-base font-medium"
              >
                Explore Programs
                <ArrowRight className="w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="gap-2 text-base font-medium"
              >
                <Play className="w-4 h-4" />
                Watch Demo
              </Button>
            </motion.div>

            {/* Stats */}
            <motion.div 
              variants={itemVariants}
              className="flex flex-wrap gap-8"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary-100 flex items-center justify-center">
                  <Users className="w-5 h-5 text-primary-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-text-primary font-display">
                    {platformStats.totalStudents.toLocaleString()}+
                  </div>
                  <div className="text-sm text-text-tertiary">Students Trained</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-amber-100 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-text-primary font-display">
                    {platformStats.placementRate}%
                  </div>
                  <div className="text-sm text-text-tertiary">Placement Rate</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-100 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-text-primary font-display">
                    {platformStats.salaryIncrease}%
                  </div>
                  <div className="text-sm text-text-tertiary">Avg. Salary Increase</div>
                </div>
              </div>
            </motion.div>
          </motion.div>

          {/* Right Column - Visual */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.3, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="relative hidden lg:block"
          >
            <div className="relative aspect-square max-w-lg mx-auto">
              {/* Main Visual - Code/AI Abstract */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary-600 to-cyan-600 opacity-10" />
              
              {/* Floating Cards */}
              <motion.div
                className="absolute top-8 left-8 bg-surface border border-border p-4 shadow-card"
                animate={prefersReducedMotion ? {} : { y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary-100 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-primary-600" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-text-primary">AI Model</div>
                    <div className="text-xs text-text-tertiary">Training Complete</div>
                  </div>
                </div>
              </motion.div>

              <motion.div
                className="absolute top-1/3 right-0 bg-surface border border-border p-4 shadow-card"
                animate={prefersReducedMotion ? {} : { y: [0, 10, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-100 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-text-primary">Accuracy</div>
                    <div className="text-xs text-emerald-600 font-medium">94.7%</div>
                  </div>
                </div>
              </motion.div>

              <motion.div
                className="absolute bottom-16 left-0 bg-surface border border-border p-4 shadow-card"
                animate={prefersReducedMotion ? {} : { y: [0, -8, 0] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-amber-100 flex items-center justify-center">
                    <Users className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-text-primary">Cohort</div>
                    <div className="text-xs text-text-tertiary">28 Students</div>
                  </div>
                </div>
              </motion.div>

              {/* Central Code Block */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-surface-alt border border-border p-6 font-mono text-sm">
                  <div className="text-text-tertiary mb-2"># Train your first model</div>
                  <div className="text-primary-600">import</div>
                  <div className="text-text-primary ml-4">tensorflow as tf</div>
                  <div className="text-cyan-600 mt-2">model = tf.keras.Sequential([</div>
                  <div className="text-text-primary ml-4">tf.keras.layers.Dense(128),</div>
                  <div className="text-text-primary ml-4">tf.keras.layers.Dense(10)</div>
                  <div className="text-cyan-600">])</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
