"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { staggerContainer, fadeUpItem } from "@/lib/animations";
import { useReducedMotion } from "@/lib/hooks/useReducedMotion";
import { cohorts, courses } from "@/data/mockData";
import { Calendar, MapPin, Globe, Users, CheckCircle, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { format, parseISO } from "date-fns";

export function TrainingSchedule() {
  const prefersReducedMotion = useReducedMotion();
  const [selectedCohort, setSelectedCohort] = useState<string | null>(null);
  
  const containerVariants = prefersReducedMotion ? {} : staggerContainer;
  const itemVariants = prefersReducedMotion ? {} : fadeUpItem;

  const getCourseById = (courseId: string) => courses.find(c => c.id === courseId);

  const inclusions = [
    "Live instruction + recordings",
    "Hands-on lab environments",
    "Certification exam voucher",
    "1-year community access",
    "Career support & job referrals",
  ];

  return (
    <section className="section-padding bg-surface-alt">
      <div className="max-w-container mx-auto px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
        >
          {/* Section Header */}
          <motion.div variants={itemVariants} className="text-center mb-12">
            <span className="label-mono text-primary-600 mb-4 block">
              UPCOMING COHORTS
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-text-primary mb-4 font-display">
              Start Your Journey
            </h2>
            <p className="text-text-secondary text-lg max-w-2xl mx-auto">
              Join a cohort of motivated learners and get hands-on training from industry experts.
            </p>
          </motion.div>

          {/* Cohorts List */}
          <motion.div variants={itemVariants} className="space-y-4">
            {cohorts.map((cohort) => {
              const course = getCourseById(cohort.courseId);
              const isSelected = selectedCohort === cohort.id;
              
              return (
                <motion.div
                  key={cohort.id}
                  className={cn(
                    "border transition-all cursor-pointer",
                    isSelected
                      ? "border-primary-400 bg-primary-50/50"
                      : "border-border bg-surface hover:border-primary-300"
                  )}
                  onClick={() => setSelectedCohort(isSelected ? null : cohort.id)}
                  role="button"
                  tabIndex={0}
                  aria-expanded={isSelected}
                >
                  {/* Main Row */}
                  <div className="p-6">
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                      {/* Date & Format */}
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-16 h-16 bg-surface-alt border border-border flex flex-col items-center justify-center">
                          <span className="text-xs text-text-tertiary uppercase label-mono">
                            {format(parseISO(cohort.startDate), "MMM")}
                          </span>
                          <span className="text-xl font-bold text-text-primary font-display">
                            {format(parseISO(cohort.startDate), "d")}
                          </span>
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-semibold text-lg text-text-primary">
                              {course?.title}
                            </h4>
                            <StatusBadge 
                              variant={cohort.availability.status} 
                              text={cohort.availability.status.replace('-', ' ')} 
                              withPulse={cohort.availability.status === 'filling-fast'}
                              className="py-1 px-2"
                            />
                          </div>
                          <div className="flex flex-wrap items-center gap-4 text-sm text-text-secondary">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {cohort.schedule.days.join(", ")}
                            </span>
                            <span className="flex items-center gap-1">
                              <Globe className="w-4 h-4" />
                              {cohort.timezone}
                            </span>
                            <span className="flex items-center gap-1">
                              {cohort.format === "Live Online" ? <Globe className="w-4 h-4" /> : <MapPin className="w-4 h-4" />}
                              {cohort.format}
                              {cohort.location && ` • ${cohort.location}`}
                            </span>
                            <span className="flex items-center gap-1">
                              <Users className="w-4 h-4" />
                              {cohort.availability.spotsRemaining} spots left
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      {/* Price & CTA */}
                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <div className="text-2xl font-bold text-primary-600 font-display">
                            ${cohort.pricing.earlyBird?.amount || cohort.pricing.standard}
                          </div>
                          {cohort.pricing.earlyBird && (
                            <div className="text-xs text-text-tertiary">
                              Early bird ends {format(parseISO(cohort.pricing.earlyBird.deadline), "MMM d")}
                            </div>
                          )}
                        </div>
                        <Button 
                          variant={cohort.availability.status === 'available' ? 'default' : 'outline'} 
                          className="min-w-[140px]"
                        >
                          {cohort.availability.status === 'available' ? 'Enroll Now' : 'Join Waitlist'}
                        </Button>
                        <ChevronDown 
                          className={cn(
                            "w-5 h-5 text-text-tertiary transition-transform",
                            isSelected && "rotate-180"
                          )} 
                        />
                      </div>
                    </div>
                  </div>

                  {/* Expanded Content */}
                  <AnimatePresence>
                    {isSelected && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                      >
                        <div className="px-6 pb-6 pt-2 border-t border-border">
                          <div className="grid md:grid-cols-2 gap-6">
                            {/* Instructor */}
                            <div>
                              <h5 className="font-medium mb-3 text-text-primary label-mono">INSTRUCTOR</h5>
                              <div className="flex items-center gap-3">
                                <img 
                                  src={cohort.instructor.avatar} 
                                  alt={cohort.instructor.name}
                                  className="w-12 h-12 object-cover"
                                />
                                <div>
                                  <div className="font-medium text-text-primary">{cohort.instructor.name}</div>
                                  <div className="text-sm text-text-secondary">{cohort.instructor.title}</div>
                                  <div className="text-xs text-text-tertiary">{cohort.instructor.company}</div>
                                </div>
                              </div>
                            </div>
                            
                            {/* What's Included */}
                            <div>
                              <h5 className="font-medium mb-3 text-text-primary label-mono">WHAT&apos;S INCLUDED</h5>
                              <ul className="space-y-2">
                                {inclusions.map((item) => (
                                  <li key={item} className="flex items-center gap-2 text-sm text-text-secondary">
                                    <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                                    {item}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
