"use client";

import { motion } from "framer-motion";
import { staggerContainer, fadeUpItem } from "@/lib/animations";
import { useReducedMotion } from "@/lib/hooks/useReducedMotion";
import { partners } from "@/data/mockData";

export function TrustSignals() {
  const prefersReducedMotion = useReducedMotion();
  
  const containerVariants = prefersReducedMotion ? {} : staggerContainer;
  const itemVariants = prefersReducedMotion ? {} : fadeUpItem;

  return (
    <section className="py-12 border-b border-border bg-surface">
      <div className="max-w-container mx-auto px-6">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="text-center"
        >
          <motion.p 
            variants={itemVariants}
            className="text-sm text-text-tertiary mb-8 label-mono"
          >
            TRUSTED BY ENGINEERS AT
          </motion.p>
          
          <motion.div 
            variants={itemVariants}
            className="flex flex-wrap justify-center items-center gap-8 md:gap-12 lg:gap-16"
          >
            {partners.map((partner) => (
              <div 
                key={partner.id}
                className="group relative grayscale hover:grayscale-0 transition-all duration-300 opacity-60 hover:opacity-100"
              >
                <img 
                  src={partner.logo} 
                  alt={partner.name}
                  className="h-6 md:h-8 w-auto object-contain"
                />
              </div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
