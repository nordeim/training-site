// Course Types
export interface Course {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  description: string;
  shortDescription?: string;
  thumbnail: { src: string; alt: string };
  coverImage?: { src: string; alt: string };
  promoVideo?: string;
  badge?: { text: string; variant: 'new' | 'popular' | 'urgent' | 'bestseller' };
  modules: Module[];
  duration: string;
  totalHours: number;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  rating: number;
  reviewCount: number;
  enrolledCount: number;
  price: { amount: number; currency: string; original?: number };
  nextCohort: string;
  spotsRemaining?: number;
  waitlistAvailable: boolean;
  categories: string[];
  categoryColor?: string;
  skills: string[];
  isFeatured: boolean;
  isActive: boolean;
  isCertification: boolean;
  certificationName?: string;
  language: string;
  metaTitle?: string;
  metaDescription?: string;
}

export interface Module {
  id: string;
  title: string;
  description: string;
  duration: string;
  order: number;
}

// Cohort Types
export interface Cohort {
  id: string;
  courseId: string;
  course?: Course;
  startDate: string;
  endDate: string;
  timezone: string;
  format: 'Live Online' | 'In-Person' | 'Hybrid';
  location?: string;
  instructor: Instructor;
  availability: {
    status: 'available' | 'filling-fast' | 'waitlist' | 'closed';
    spotsTotal: number;
    spotsRemaining: number;
  };
  pricing: {
    earlyBird?: { amount: number; deadline: string };
    standard: number;
  };
  schedule: {
    days: string[];
    time: string;
  };
  status: 'draft' | 'open' | 'filling' | 'waitlist' | 'closed';
  maxStudents: number;
}

export interface Instructor {
  id: string;
  name: string;
  title: string;
  avatar?: string;
  company?: string;
  bio?: string;
}

// User Types
export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  avatar?: string;
  role: 'student' | 'instructor' | 'admin';
  createdAt: string;
  updatedAt: string;
}

export interface Enrollment {
  id: string;
  userId: string;
  cohortId: string;
  cohort?: Cohort;
  status: 'pending' | 'active' | 'completed' | 'cancelled';
  progress: number;
  enrolledAt: string;
  completedAt?: string;
  certificateUrl?: string;
}

// Category Types
export interface CourseCategory {
  id: string;
  name: string;
  slug: string;
  description: string;
  color: string;
  icon: string;
  courseCount: number;
}

// Navigation Types
export interface NavItem {
  label: string;
  href: string;
  children?: NavItem[];
}

// Stats Types
export interface PlatformStats {
  totalCourses: number;
  totalStudents: number;
  averageRating: number;
  placementRate: number;
  salaryIncrease: number;
}

// Testimonial Types
export interface Testimonial {
  id: string;
  name: string;
  title: string;
  company: string;
  avatar?: string;
  content: string;
  rating: number;
  courseName: string;
}

// Partner Types
export interface Partner {
  id: string;
  name: string;
  logo: string;
  website?: string;
}

// Feature Types
export interface Feature {
  id: string;
  title: string;
  description: string;
  icon: string;
}

// API Response Types
export interface ApiResponse<T> {
  data: T;
  message?: string;
  success: boolean;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  perPage: number;
  totalPages: number;
}

// Filter Types
export interface CourseFilters {
  category?: string;
  level?: string;
  format?: string;
  search?: string;
  sortBy?: 'popularity' | 'rating' | 'newest' | 'price-low' | 'price-high';
}

// Form Types
export interface LoginFormData {
  email: string;
  password: string;
}

export interface RegisterFormData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export interface EnrollmentFormData {
  cohortId: string;
  paymentMethodId: string;
}
